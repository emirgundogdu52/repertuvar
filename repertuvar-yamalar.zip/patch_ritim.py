# -*- coding: utf-8 -*-
# repertoires.js — MAKAM MODUNA RİTİM + TEMPO ANAHTARI (2026-09-05)
import io

P = 'repertoires.js'
s = io.open(P, encoding='utf-8').read()
onceki = len(s.encode('utf-8'))

# ── 1) WL'e usul / olcu / tempo ──────────────────────────────────────────
old = ("    WL[id] = { name: w.name||'', composer: w.composer||'', makam: w.makam||'', "
       "instrument: w.instrument||'', closingNote: w.closing_note||'', lyrics: w.lyrics||'', "
       "videoLink: w.video_link||'' };")
new = ("    // (2026-09-05) usul/olcu/tempo eklendi — Sırala'da ritim+tempo anahtarı için.\n"
       "    //   works sorgusunda select= YOK, bu üç sütun zaten ağdan iniyordu; sadece burada eleniyordu.\n"
       "    WL[id] = { name: w.name||'', composer: w.composer||'', makam: w.makam||'', "
       "instrument: w.instrument||'', closingNote: w.closing_note||'', lyrics: w.lyrics||'', "
       "videoLink: w.video_link||'', usul: w.usul||'', olcu: w.olcu||'', tempo: w.tempo||'' };")
assert s.count(old) == 1, 'WL satiri bulunamadi/tekil degil: %d' % s.count(old)
s = s.replace(old, new)

# ── 2) customWorks fallback dali ─────────────────────────────────────────
old = ("else WL[sid]={name:w.name||'',lyrics:w.lyrics||'',composer:w.composer||'',makam:w.makam||'',"
       "instrument:w.instrument||'',closingNote:w.closingNote||'',videoLink:w.videoLink||''};")
new = ("else WL[sid]={name:w.name||'',lyrics:w.lyrics||'',composer:w.composer||'',makam:w.makam||'',"
       "instrument:w.instrument||'',closingNote:w.closingNote||'',videoLink:w.videoLink||'',"
       "usul:w.usul||'',olcu:w.olcu||'',tempo:w.tempo||''};")
assert s.count(old) == 1, 'customWorks fallback bulunamadi: %d' % s.count(old)
s = s.replace(old, new)

# ── 3) Yardimcilar + workProfile'a ritim/tempo ───────────────────────────
old = "function workProfile(it){"
new = """// ── RİTİM/TEMPO ANAHTARLARI (2026-09-05) ────────────────────────────────
// Boş usul/ölçü/tempo taşıyan eserler makam grubunun BAŞINDA kümelenir
// (listenin sonuna itilmez). Sona almak için tek satır: false -> true.
const _BOS_SONA = false;

// Usul birincil, ölçü yedek. Ham "9/8" tek başına yetersiz anahtar:
// Aksak, Ağır Aksak, Türk Aksağı ve Roman havası hepsi 9/8 ama aynı şey değil.
function ritimKey(w){
  const v = (w.usul || w.olcu || '').trim().toLocaleLowerCase('tr');
  return v || (_BOS_SONA ? '\\uffff' : '');
}
// tempo metin olabilir ("108", "108 bpm"); rakam dışını at.
function tempoKey(w){
  const n = parseInt(String(w.tempo || '').replace(/[^0-9]/g, ''), 10);
  if (!n || n <= 0) return _BOS_SONA ? Infinity : -Infinity;
  return n;
}

function workProfile(it){"""
assert s.count(old) == 1, 'workProfile bulunamadi: %d' % s.count(old)
s = s.replace(old, new)

old = ("  return {name:w.name||('#'+it.workId), makamAd:mk?mk.ad:'', aile:mk?mk.aile:'',\n"
       "          karar, bilinmiyor:!mk && (base===null||base===undefined), "
       "kararTxt:it.closingNote||w.closingNote||(mk?mk.kararPerde:'')};")
new = ("  return {name:w.name||('#'+it.workId), makamAd:mk?mk.ad:'', aile:mk?mk.aile:'',\n"
       "          karar, bilinmiyor:!mk && (base===null||base===undefined), "
       "kararTxt:it.closingNote||w.closingNote||(mk?mk.kararPerde:''),\n"
       "          ritim:ritimKey(w), tempo:tempoKey(w), ritimTxt:(w.usul||w.olcu||''), "
       "tempoTxt:(w.tempo||'')};")
assert s.count(old) == 1, 'workProfile return bulunamadi: %d' % s.count(old)
s = s.replace(old, new)

# ── 4) Comparator: makam -> ritim -> tempo ───────────────────────────────
old = "    sorted=movable.slice().sort((x,y)=> (x.inP.makamAd||'zzz').localeCompare(y.inP.makamAd||'zzz','tr'));"
new = ("    // (2026-09-05) Aynı makam içinde ritim, aynı ritim içinde tempo artan.\n"
       "    // Örn. 9/8 Hicaz bloğu tempo 90'dan 110'a doğru sıralanır.\n"
       "    // Array.prototype.sort stable: üç anahtar da eşitse mevcut sıra korunur.\n"
       "    sorted=movable.slice().sort((x,y)=>\n"
       "         (x.inP.makamAd||'zzz').localeCompare(y.inP.makamAd||'zzz','tr')\n"
       "      || (x.inP.ritim||'').localeCompare(y.inP.ritim||'','tr')\n"
       "      || ((x.inP.tempo) - (y.inP.tempo))\n"
       "    );")
assert s.count(old) == 1, 'comparator bulunamadi: %d' % s.count(old)
s = s.replace(old, new)

io.open(P, 'w', encoding='utf-8').write(s)
sonra = len(s.encode('utf-8'))
print('OK  %d -> %d bayt  (+%d)' % (onceki, sonra, sonra - onceki))
