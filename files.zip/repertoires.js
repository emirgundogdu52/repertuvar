// ============================================================================
// repertoires.js — changelog (son değişiklikler üstte)
// 2026-07-19 (c): Potpuri İÇEREN repertuvarlar listede ve detay başlığında 🔗
//             rozetiyle işaretleniyor (.rep-medley). Liste kartında sadece "🔗"
//             (birden fazla zincir varsa "🔗 2"), detayda "🔗 N Potpuri".
//             Zincir sayısı = ardışık linkedPrev bloklarının sayısı.
// 2026-07-19 (b): POTPURİ SÜRÜKLE-BIRAK DÜZELTMESİ. Hata: sürükle-bırak da mv()'yi
//             çağırıyordu (dir = hedef - kaynak) ama mv'nin blok dalı dir'i TEK ADIM
//             sanıyordu — zincir başı sürüklenince blok hedefe değil bir komşu kadar
//             kayıyordu; zincir üyesi dışarı sürüklendiğinde ise linked_prev true
//             kalıp altın şerit "kopmuş gibi" duruyordu. Çözüm: sıralama tek yoldan
//             geçiyor — applyReorder() + normalizeChains(). TEK KURAL: bir satırın
//             bağı, YENİ üstündeki satır o satırın ORİJİNAL zincirindense korunur,
//             değilse çözülür. Yeni mvTo(repId,src,dest) sürükle-bırak (ve chSeq)
//             için; mv() yalnız ↑/↓ tek adım. linked_prev PATCH'i yalnız DEĞİŞEN
//             satırlar için gönderilir.
// 2026-07-19: POTPURİ (medley) desteği. repertoire_items'a linked_prev boolean
//             kolonu eklendi: bir satır "bir öncekiyle kesintisiz devam ediyor"
//             demek. Potpuri = linked_prev=true olan ARDIŞIK satır zinciri
//             (ayrı grup id'si YOK — sürükle-bırak sıralamayı bozmasın diye).
//             Yeni: chainRange()/isChainHead() yardımcıları, toggleLink() (🔗
//             butonu, satırı öncekine bağlar/çözer), zincir satırlarında sol
//             altın şerit + "↳" numara, mv() zincir BAŞINA basıldığında tüm
//             bloğu taşır. idx===0 satırında linked_prev her zaman yok sayılır
//             (zincir asla listenin başında başlayamaz).
// 2026-07-17: (1) loadWorksData local-first yapıldı — eser adları/güftesi artık
//             IndexedDB'den anında geliyor, "#37" numara-yerine-ad regresyonu bitti.
//             (2) "Çevrimdışı mod" toast'ı yalnızca navigator.onLine===false iken
//             gösteriliyor — online'ken sync timeout'u artık sessiz.
//             (3) Arka plan sync timeout 6000→3500ms (ağ geçişinde asılı kalma azaldı).
// ============================================================================

const H = {
  get apikey() { return SUPA_KEY; },
  get Authorization() { return 'Bearer ' + (localStorage.getItem('sb_token') || SUPA_KEY); },
  'Content-Type': 'application/json',
  'Prefer': 'return=representation'
};
async function dbGet(table, qs='', signal) {
  const r = await fetch(SUPA_URL+'/rest/v1/'+table+'?'+qs, {headers:H, signal});
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
async function dbPost(table, data) {
  const r = await fetch(SUPA_URL+'/rest/v1/'+table, {method:'POST',headers:H,body:JSON.stringify(data)});
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
async function dbPatch(table, id, data) {
  const r = await fetch(SUPA_URL+'/rest/v1/'+table+'?id=eq.'+id, {method:'PATCH',headers:H,body:JSON.stringify(data)});
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
async function dbDel(table, id) {
  const r = await fetch(SUPA_URL+'/rest/v1/'+table+'?id=eq.'+id, {method:'DELETE',headers:H});
  if (!r.ok) throw new Error(await r.text());
  return true;
}
async function dbDelWhere(table, col, val) {
  const r = await fetch(SUPA_URL+'/rest/v1/'+table+'?'+col+'=eq.'+val, {method:'DELETE',headers:H});
  if (!r.ok) throw new Error(await r.text());
  return true;
}


let WL = {};
let WLIST = [];
let repSearchQuery = '';

function onRepSearchInput(val) {
  repSearchQuery = val || '';
  renderList();
}

function repMatchesSearch(r, q) {
  if (!q) return true;
  const norm = s => (s || '').toLocaleLowerCase('tr');
  const nq = norm(q);
  if (norm(r.name).includes(nq)) return true;
  return (r.items || []).some(it => {
    const w = WL[it.workId] || {};
    return norm(w.name).includes(nq);
  });
}

// ── Swipe-to-delete + swipe-to-değiştir (Repertuvarlar listesi) ──
const RI_SWIPE_THRESHOLD = 44;   // bu kadar kaydırınca "açık" sayılır
const RI_SWIPE_MAX = 84;         // silme/değiştir butonunun genişliği kadar
let _riSwipe = null;
let _riOpenCard = null; // o an açık (buton görünür) kart

function riCloseOpenCard() {
  if (_riOpenCard) {
    _riOpenCard.style.transition = 'transform .2s ease';
    _riOpenCard.style.transform = 'translateX(0)';
    _riOpenCard.classList.remove('swiped-open-left', 'swiped-open-right');
    const wrap = _riOpenCard.closest('.ri-wrap');
    if (wrap) { wrap.style.transition = 'opacity .2s ease'; wrap.style.setProperty('--swipe-glow', 0); }
    _riOpenCard = null;
  }
}

function riTouchStart(e) {
  if (_riOpenCard && _riOpenCard !== e.currentTarget) riCloseOpenCard();
  const t = e.touches[0];
  _riSwipe = { card: e.currentTarget, startX: t.clientX, startY: t.clientY, dx: 0, dir: null };
}

function riTouchMove(e) {
  if (!_riSwipe || _riSwipe.card !== e.currentTarget) return;
  const t = e.touches[0];
  const dx = t.clientX - _riSwipe.startX;
  const dy = t.clientY - _riSwipe.startY;
  if (_riSwipe.dir === null) {
    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
      _riSwipe.dir = Math.abs(dx) > Math.abs(dy) ? 'h' : 'v';
    }
  }
  if (_riSwipe.dir === 'v') { _riSwipe = null; return; }
  if (_riSwipe.dir === 'h') {
    e.preventDefault();
    let base = 0;
    if (_riSwipe.card.classList.contains('swiped-open-right')) base = -RI_SWIPE_MAX; // sil/gizle paneli açıktı
    else if (_riSwipe.card.classList.contains('swiped-open-left')) base = RI_SWIPE_MAX; // değiştir paneli açıktı
    const clamped = Math.min(RI_SWIPE_MAX, Math.max(base + dx, -RI_SWIPE_MAX));
    _riSwipe.dx = clamped;
    _riSwipe.card.style.transition = 'none';
    _riSwipe.card.style.transform = `translateX(${clamped}px)`;
    const wrap = _riSwipe.card.closest('.ri-wrap');
    if (wrap) wrap.style.setProperty('--swipe-glow', Math.min(1, Math.abs(clamped) / RI_SWIPE_MAX));
  }
}

function riTouchEnd(e) {
  if (!_riSwipe || _riSwipe.dir !== 'h') { _riSwipe = null; return; }
  const card = _riSwipe.card;
  card.style.transition = 'transform .2s ease';
  // Gerçek bir yatay hareket olduysa (ne kadar küçük olursa olsun), bunu takip eden
  // "click" olayını görmezden gel — bir swipe denemesi asla kart seçimine dönüşmemeli.
  if (Math.abs(_riSwipe.dx) > 5) card.dataset.justSwiped = '1';
  card.classList.remove('swiped-open-left', 'swiped-open-right');
  const wrap = card.closest('.ri-wrap');
  if (_riSwipe.dx <= -RI_SWIPE_THRESHOLD) {
    card.style.transform = `translateX(${-RI_SWIPE_MAX}px)`;
    card.classList.add('swiped-open-right'); // sağdaki (Sil/Gizle) panel açık
    if (wrap) wrap.style.setProperty('--swipe-glow', 1);
    _riOpenCard = card;
  } else if (_riSwipe.dx >= RI_SWIPE_THRESHOLD) {
    card.style.transform = `translateX(${RI_SWIPE_MAX}px)`;
    card.classList.add('swiped-open-left'); // soldaki (Değiştir) panel açık
    if (wrap) wrap.style.setProperty('--swipe-glow', 1);
    _riOpenCard = card;
  } else {
    card.style.transform = 'translateX(0)';
    if (wrap) { wrap.style.transition = 'opacity .2s ease'; wrap.style.setProperty('--swipe-glow', 0); }
    if (_riOpenCard === card) _riOpenCard = null;
  }
  _riSwipe = null;
}

function riCardClick(e, id) {
  const card = e.currentTarget;
  if (card.classList.contains('swiped-open-left') || card.classList.contains('swiped-open-right')) {
    riCloseOpenCard();
    return;
  }
  if (card.dataset.justSwiped === '1') {
    delete card.dataset.justSwiped;
    return;
  }
  sel(id);
}

// Sayfa bfcache'den (geri/ileri önbelleği) geri geldiğinde önceki kaydırma durumu
// donmuş halde kalabiliyor (özellikle ilk kartın "silmeye hazır" görünmesi). Her
// pageshow'da (hem normal yükleme hem bfcache restore) temiz duruma sıfırla.
window.addEventListener('pageshow', () => {
  document.querySelectorAll('.ri.swiped-open-left, .ri.swiped-open-right').forEach(card => {
    card.classList.remove('swiped-open-left', 'swiped-open-right');
    card.style.transition = 'none';
    card.style.transform = 'translateX(0)';
    delete card.dataset.justSwiped;
    const wrap = card.closest('.ri-wrap');
    if (wrap) wrap.style.setProperty('--swipe-glow', 0);
  });
  _riOpenCard = null;
  _riSwipe = null;
});

// "Diğer İşlemler" menüsü dışına tıklanınca kapat
document.addEventListener('click', (e) => {
  document.querySelectorAll('.ov-menu[open]').forEach(d => {
    if (!d.contains(e.target)) d.removeAttribute('open');
  });
  if (_riOpenCard && !_riOpenCard.contains(e.target)) riCloseOpenCard();
});

// WL/WLIST'i verilen works satırlarından (yerel ya da sunucu) sıfırdan kurar.
// Her çağrıda resetler ki local→sunucu tazelemesinde WLIST'te çift kayıt olmasın.
function _applyWorksRows(rows) {
  WL = {}; WLIST = [];
  (rows||[]).forEach(w => {
    const id = String(w.id);
    WL[id] = { name: w.name||'', composer: w.composer||'', makam: w.makam||'', instrument: w.instrument||'', closingNote: w.closing_note||'', lyrics: w.lyrics||'' };
    WLIST.push({ id, name: w.name||'', composer: w.composer||'', makam: w.makam||'' });
  });
  // customWorks patch (yerel override'lar)
  try {
    const customs = JSON.parse(localStorage.getItem('customWorks') || '[]');
    const deleted = JSON.parse(localStorage.getItem('deletedWorks') || '[]');
    deleted.forEach(function(did){ var sid=String(parseInt(did)); delete WL[sid]; for(var j=WLIST.length-1;j>=0;j--){if(WLIST[j].id===sid){WLIST.splice(j,1);break;}} });
    customs.forEach(function(w){ var sid=String(parseInt(w.id)); if(WL[sid]){if(w.name)WL[sid].name=w.name;if(w.lyrics!==undefined)WL[sid].lyrics=w.lyrics;} else WL[sid]={name:w.name||'',lyrics:w.lyrics||'',composer:w.composer||'',makam:w.makam||'',instrument:w.instrument||'',closingNote:w.closingNote||''}; var found=false; for(var k=0;k<WLIST.length;k++){if(WLIST[k].id===sid){if(w.name)WLIST[k].name=w.name;found=true;break;}} if(!found)WLIST.push({id:sid,name:w.name||'',composer:w.composer||'',makam:w.makam||''}); });
  } catch(e) {}
}

async function loadWorksData() {
  // ── 1) ÖNCE LOCAL (IndexedDB): WL'i anında doldur, beklemeden çiz ──
  //     Böylece eser adları/güftesi ağ beklemeden gelir; "#37" görünmez.
  if (window.db) {
    try {
      const localRows = await db.works.getAll();
      if ((localRows||[]).length) {
        _applyWorksRows(localRows);
        try { renderList(); renderDetail(); } catch(e) {}
      }
    } catch(e) { console.warn('[repertoires] works local okuma hatası:', e); }
  }
  // ── 2) ARKA PLANDA sunucudan tazele (asılı kalmasın diye kısa timeout) ──
  try {
    const r = await fetch(SUPA_URL+'/rest/v1/works?order=name&limit=2000', {
      headers: {'apikey': SUPA_KEY, 'Authorization': 'Bearer '+SUPA_KEY},
      signal: AbortSignal.timeout(3500)
    });
    if (!r.ok) throw new Error('works fetch '+r.status);
    const rows = await r.json();
    if ((rows||[]).length) {
      if (window.db) { try { await db.works.saveAll(rows); } catch(e) {} }
      _applyWorksRows(rows);
      try { renderList(); renderDetail(); } catch(e) {}
    }
  } catch(fetchErr) {
    // Sunucudan tazeleyemedik — sorun değil, WL zaten local'den dolu.
    console.warn('[repertoires] Works sunucudan tazelenemedi, local kullanılıyor:', fetchErr.message);
  }
}
let reps=[], selId=null, editId=null, selWId=null, addRepId=null, activeItemIdx=null, activeItemRepId=null;

function dbg(msg){ /* debug removed */ }

function sync(s,t){const d=document.getElementById('dot');const sl=document.getElementById('sl');if(d)d.className='dot '+s;if(sl)sl.textContent=t;}
function toast(m,t='ok'){const e=document.createElement('div');e.className='toast '+t;e.textContent=m;document.body.appendChild(e);setTimeout(()=>e.remove(),2500);}

let SOLISTLER = []; // sanatçı listesi

function applyRepsData(r, i, s) {
  SOLISTLER = (s||[]).map(x=>x.name).filter(Boolean);
  const uid = getUserId() || '';
  // linkedPrev: ilk satırda her zaman false — zincir listenin başında başlayamaz.
  reps = (r||[]).map(x=>({...x, isOwner: x.owner_id===uid || x.user_id===uid, items:(i||[]).filter(t=>t.repertoire_id===x.id).sort((a,b)=>a.seq-b.seq).map((t,ix)=>({...t,workId:String(t.work_id),closingNote:t.closing_note||'',performer:t.performer||'',linkedPrev: ix>0 && !!t.linked_prev}))}));
}

function selectUrlRepIfPresent() {
  const urlRep=new URLSearchParams(window.location.search).get('rep');
  if(urlRep&&reps.find(x=>x.id===urlRep)){selId=urlRep;}
}

async function load(){
  dbg('load() başladı');
  let localHadData = false;

  // ── 1) ÖNCELİKLE LOCAL'DEN ANINDA GÖSTER (sinyal zayıf/yokken bile beklemeden) ──
  if (window.db) {
    try {
      const [rLocal, iLocal, sLocal] = await Promise.all([
        db.repertoires.getAll(),
        db.repertoire_items.getAll(),
        db.solistler.getAll()
      ]);
      if ((rLocal||[]).length) {
        applyRepsData(rLocal, iLocal, sLocal);
        localHadData = true;
        sync('ok','Yerel veri');
        selectUrlRepIfPresent();
        renderList(); renderDetail();
        setTimeout(fixMobileHeight, 100);
        dbg('local\'den anında gösterildi: '+rLocal.length+' repertuvar');
      }
    } catch(e) { dbg('local okuma hatası: '+e.message); }
  }
  if (!localHadData) sync('spin','Yükleniyor...');

  // ── 2) ARKA PLANDA SUNUCUYLA SENKRONİZE ET (timeout'lu — asılı kalmasın) ──
  try{
    const uid2 = getUserId();
    const gid = getGroupId();
    const repQuery = gid
      ? 'order=created_at&limit=100&or=(owner_id.eq.'+uid2+',group_id.eq.'+gid+',is_public.eq.true)'
      : (uid2
        ? 'order=created_at&limit=100&or=(owner_id.eq.'+uid2+',is_public.eq.true)'
        : 'order=created_at&limit=100&is_public=eq.true');
    const solQuery = gid ? 'order=name&group_id=eq.'+gid : 'order=name';
    // Yerel veri zaten ekrandaysa uzun beklemeye gerek yok — 3.5 sn'de gelmezse
    // sessizce local ile devam. Yerel veri yoksa ağa biraz daha şans ver (4.5 sn).
    const timeoutMs = localHadData ? 3500 : 4500;
    const [r,i,s] = await Promise.all([
      dbGet('repertoires', repQuery, AbortSignal.timeout(timeoutMs)),
      dbGet('repertoire_items','order=seq', AbortSignal.timeout(timeoutMs)),
      dbGet('solistler', solQuery, AbortSignal.timeout(timeoutMs))
    ]);
    dbg('sunucudan geldi — rep sayısı: '+(r||[]).length+' | items: '+(i||[]).length);
    if (window.db) {
      await db.repertoires.replaceAll(r||[]);
      await db.solistler.replaceAll(s||[]);
      await db.repertoire_items.replaceAll(i||[]);
    }
    applyRepsData(r, i, s);
    sync('ok','Senkronize');
    selectUrlRepIfPresent();
    if (!_riSwipe && !_riOpenCard) { renderList(); renderDetail(); }
    setTimeout(fixMobileHeight, 100);
  }catch(fetchErr){
    dbg('sunucu senkronizasyonu başarısız (offline/zayıf sinyal): '+fetchErr.message);
    if (!localHadData) {
      // Local'de de veri yoktu, ağ da başarısız oldu — boş liste göster
      renderList(); renderDetail();
    }
    // navigator.onLine === false → cihaz GERÇEKTEN çevrimdışı (güvenilir negatif sinyal).
    // Online'ken sync sadece timeout olduysa yerel veri zaten ekranda; kullanıcıyı
    // "çevrimdışısın" diye yanıltma.
    const reallyOffline = (navigator.onLine === false);
    if (localHadData) {
      sync('ok', reallyOffline ? 'Çevrimdışı — yerel veri' : 'Senkronize edilemedi');
    } else {
      sync('err', reallyOffline ? 'Çevrimdışı' : 'Bağlantı hatası');
    }
    if (reallyOffline) toast('📵 Çevrimdışı mod — yerel veriler gösteriliyor', 'ok');
  }
}

function fixMobileHeight() {
  if (window.innerWidth >= 768) return;
  const topnav = document.querySelector('.r-topnav') || document.querySelector('.v2-topnav');
  const botnav = document.querySelector('.r-bottom-nav') || document.querySelector('.v2-bottom-nav');
  const lp = document.querySelector('.lp');
  const ls = document.getElementById('list');
  if (!lp || !ls) return;
  const topH = topnav ? topnav.offsetHeight : 56;
  const botH = botnav ? botnav.offsetHeight : 68;
  const available = window.innerHeight - topH - botH;
  lp.style.height = available + 'px';
  lp.style.maxHeight = available + 'px';
  const lph = lp.querySelector('.lph');
  const lphH = lph ? lph.offsetHeight : 50;
  ls.style.height = (available - lphH) + 'px';
  ls.style.overflowY = 'scroll';
}

function getHiddenRepIds() {
  try { return JSON.parse(localStorage.getItem('hiddenRepIds') || '[]'); }
  catch (e) { return []; }
}
function hideRepFromView(id) {
  const hidden = getHiddenRepIds();
  if (!hidden.includes(id)) hidden.push(id);
  localStorage.setItem('hiddenRepIds', JSON.stringify(hidden));
  toast('Görünümünden kaldırıldı');
  renderList();
}

function renderList(){
  const el=document.getElementById('list');
  if(!reps.length){el.innerHTML='<div style="padding:30px 16px;text-align:center;color:var(--text3);">Henüz repertuvar yok</div>';return;}
  const filtered = reps.filter(r=>repMatchesSearch(r, repSearchQuery));
  if(repSearchQuery && !filtered.length){el.innerHTML='<div style="padding:30px 16px;text-align:center;color:var(--text3);">"'+repSearchQuery+'" için sonuç bulunamadı</div>';return;}
  const sl={concept:'Taslak',confirmed:'Onaylandı',archive:'Arşiv'};
  const sc={concept:'sc',confirmed:'sf',archive:'sa'};
  const hiddenIds = getHiddenRepIds();
  const mine = filtered.filter(r=>r.isOwner);
  const pub  = filtered.filter(r=>!r.isOwner && r.is_public && !hiddenIds.includes(r.id));
    // POTPURİ sayacı — repertuvarda kaç ayrı zincir var (ardışık linkedPrev blokları)
  function medleyCount(r){
    const its=r.items||[]; let n=0;
    for(let i=1;i<its.length;i++){ if(its[i].linkedPrev && !its[i-1].linkedPrev) n++; }
    return n;
  }
  function repCard(r, _zi){
    const mc = medleyCount(r);
    const medleyChip = mc ? `<span class="rep-medley" title="${mc===1?'Bu repertuvarda bir potpuri var':'Bu repertuvarda '+mc+' potpuri var'}">🔗${mc>1?' '+mc:''}</span>` : '';
    const touchAttrs = `ontouchstart="riTouchStart(event)" ontouchmove="riTouchMove(event)" ontouchend="riTouchEnd(event)" ontouchcancel="riTouchEnd(event)"`;
    const cardHtml = `<div class="ri${selId===r.id?' active':''}" onclick="riCardClick(event,'${r.id}')" ${touchAttrs}>
      <div><div class="rn">${r.name}${r.is_public&&r.isOwner?' <span style="font-size:10px;color:#4ade80;font-weight:600;">🌐</span>':''}</div>
      <div class="rm"><span class="sp ${sc[r.status]||'sc'}">${sl[r.status]||'Taslak'}</span>${medleyChip}${r.date?'<span>'+r.date+'</span>':''}</div></div>
      <div class="rc">${(r.items||[]).length} eser</div>
    </div>`;
    // Kendi repertuvarında: gerçekten SİL (kırmızı). Başkasınınkinde: sadece kendi
    // görünümünden GİZLE (mavi) — orijinal veriye, sahibine ya da gruba hiç dokunmuyor.
    // Sağa kaydırınca (her ikisinde de) DEĞİŞTİR (mavi, sol) — kartı tıklamakla aynı.
    const editBg = `<div class="ri-edit-bg" onclick="event.stopPropagation();riCloseOpenCard();sel('${r.id}')"><i class="ti ti-edit"></i>Değiştir</div>`;
    if (r.isOwner) {
      return `<div class="ri-wrap">
        ${editBg}
        <div class="ri-delete-bg" onclick="event.stopPropagation();riCloseOpenCard();delRep('${r.id}')"><i class="ti ti-trash"></i>Sil</div>
        ${cardHtml}
      </div>`;
    }
    return `<div class="ri-wrap">
      ${editBg}
      <div class="ri-delete-bg ri-hide-bg" onclick="event.stopPropagation();riCloseOpenCard();hideRepFromView('${r.id}')"><i class="ti ti-eye-off"></i>Gizle</div>
      ${cardHtml}
    </div>`;
  }
  let html = '';
  if(mine.length){
    html += '<div style="padding:8px 12px 4px;font-size:17px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.07em;">📁 Repertuvarlarım</div>';
    html += mine.map(repCard).join('');
  }
  if(pub.length){
    html += '<div style="padding:12px 12px 4px;font-size:17px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.07em;border-top:1px solid var(--border);margin-top:8px;">🌐 Genel Repertuvarlar</div>';
    html += pub.map(repCard).join('');
  }
  el.innerHTML = html;
}

function sel(id){
  selId=id;
  renderList();
  renderDetail();
  if(window.innerWidth < 768){
    const lp=document.querySelector('.lp');
    const dp=document.getElementById('dp');
    if(lp) lp.classList.add('mobile-hidden');
    if(dp) dp.classList.add('mobile-open');
    const btn=document.getElementById('mobileBackBtn');
    if(btn) btn.style.display='flex';
  }
}

function goBackToList(){
  const lp=document.querySelector('.lp');
  const dp=document.getElementById('dp');
  if(lp) lp.classList.remove('mobile-hidden');
  if(dp) dp.classList.remove('mobile-open');
  const btn=document.getElementById('mobileBackBtn');
  if(btn) btn.style.display='none';
}
function getRep(id){return reps.find(r=>r.id===id);}

function renderDetail(){
  const rep=getRep(selId);
  document.getElementById('es').style.display=rep?'none':'flex';
  const dc=document.getElementById('dc');
  dc.style.display=rep?'block':'none';
  if(!rep)return;
  const sl={concept:'Taslak',confirmed:'Onaylandı',archive:'Arşiv'};
  const sc={concept:'sc',confirmed:'sf',archive:'sa'};
  const items=rep.items||[];
  // ── POTPURİ: zincir hesapları (linkedPrev ardışık satır zinciri) ──
  // Sıra numarası yalnızca zincir BAŞLARINDA artar; devam satırları "↳" gösterir.
  let _medleyN = 0;
  for(let i=1;i<items.length;i++){ if(items[i].linkedPrev && !items[i-1].linkedPrev) _medleyN++; }
  const _no = []; let _n = 0;
  items.forEach((it,ix)=>{ if(!(ix>0 && it.linkedPrev)) _n++; _no[ix] = (ix>0 && it.linkedPrev) ? null : _n; });
  const rows=items.length?items.map((it,idx)=>{
    const w=WL[it.workId]||{};
    const cn=it.closingNote||w.closingNote||'';
    const pf = it.performer || '';
    const isActive = activeItemRepId===rep.id && activeItemIdx===idx;
    const linked   = idx>0 && !!it.linkedPrev;                 // öncekine bağlı mı
    const hasNext  = !!(items[idx+1] && items[idx+1].linkedPrev); // sonraki bu satıra bağlı mı
    const inChain  = linked || hasNext;
    const chainCls = inChain ? (linked && hasNext ? ' medley-mid' : (linked ? ' medley-end' : ' medley-head')) : '';
    const rowClasses=[idx%2===1?'zebra-tr':'',isActive?'item-active':'',inChain?'medley-row':'',chainCls.trim()].filter(Boolean).join(' ');
    return `<tr draggable="true" data-idx="${idx}" data-rep="${rep.id}" ondragstart="dragStart(event)" ondragover="dragOver(event)" ondrop="dragDrop(event)" ondragend="dragEnd(event)" style="touch-action:pan-y;"${rowClasses?' class="'+rowClasses+'"':''}>
      <td class="sq" style="text-align:center;user-select:none;padding:0 2px;vertical-align:middle;width:48px;">
        <div style="display:flex;align-items:center;justify-content:center;gap:3px;">
          <span style="color:${isActive?'var(--accent)':(linked?'var(--accent2)':'var(--text3)')};font-size:11px;font-weight:${isActive?'700':'600'};min-width:16px;" title="${linked?'Potpuri — bir öncekiyle kesintisiz':''}">${isActive?'▶ ':''}${linked?'↳':_no[idx]}</span>
          <span class="drag-handle" ontouchstart="touchDragStart(event)" ontouchmove="touchDragMove(event)" ontouchend="touchDragEnd(event)">⠿</span>
        </div>
      </td>
      <td style="padding-left:16px;">
        <div class="wn">${linked?'<span class="medley-chip" title="Potpuri devamı">🔗</span> ':''}${w.name||'#'+it.workId}</div>
        <div class="ws">${[w.makam,w.composer].filter(Boolean).join(' · ')}</div>
        ${pf ? '<div style="font-size:11px;color:var(--accent);margin-top:2px;">🎤 '+pf+'</div>' : ''}
      </td>
      <td class="col-kapanis">${cn?'<span class="cn">'+cn+'</span>':''}</td>
      <td class="col-not" style="color:var(--text3);font-size:12px;">${it.note||''}</td>
      <td><div class="ra">
        <button class="br${activeItemRepId===rep.id&&activeItemIdx===idx?' active':''}" onclick="mvActive('${rep.id}',${idx},-1)" ${idx===0?'disabled':''}>↑</button>
        <button class="br${activeItemRepId===rep.id&&activeItemIdx===idx?' active':''}" onclick="mvActive('${rep.id}',${idx},1)" ${idx===items.length-1?'disabled':''}>↓</button>
        <button class="br bl${linked?' linked':''}" onclick="toggleLink('${rep.id}','${it.id}')" ${idx===0?'disabled':''} title="${linked?'Potpuri bağını çöz':'Bir öncekiyle potpuri yap (kesintisiz devam)'}">🔗</button>
        <button class="br be" onclick="openItemEdit('${rep.id}','${it.id}')"><i class="ti ti-edit" aria-hidden="true"></i></button>
        <button class="br dl" onclick="rmItem('${rep.id}','${it.id}','${(w.name||'Bu eser').replace(/'/g,"\\'")}')"><i class="ti ti-trash" aria-hidden="true"></i></button>
      </div></td>
    </tr>`;
  }).join(''):`<tr><td colspan="5" class="ei">Henüz eser eklenmedi.</td></tr>`;

  dc.innerHTML=`
    <div class="dh" style="padding:10px 14px 8px;">
      <div class="mobile-back-btn" onclick="goBackToList()" style="display:none;margin:-10px -14px 8px;padding:8px 14px;" id="mobileBackBtn">← Repertuvar Listesi</div>
      <div class="dn" style="font-size:14px;font-weight:600;line-height:1.4;word-break:break-word;margin-bottom:8px;">${rep.name}</div>
      <div class="cta-row">
        <a href="stage.html" class="bstage-primary" onclick="localStorage.setItem('stageRepId','${rep.id}');localStorage.setItem('stageSource','repertoires');localStorage.setItem('stageShowChords','0')"><i class="ti ti-microphone" style="font-size:15px;" aria-hidden="true"></i> Sahneye Çık</a>
        ${rep.isOwner ? `
        <details class="ov-menu">
          <summary class="bi" style="font-size:12px;padding:9px 12px;">⋯ Diğer</summary>
          <div class="ov-menu-body">
            <button onclick="openEdit('${rep.id}')"><i class="ti ti-edit" aria-hidden="true"></i> Düzenle</button>
            <button onclick="shareRep('${rep.id}')"><i class="ti ti-share" aria-hidden="true"></i> Paylaş</button>
            <button onclick="printR('${rep.id}')"><i class="ti ti-printer" aria-hidden="true"></i> Yazdır</button>
            <button class="ov-danger" onclick="delRep('${rep.id}')"><i class="ti ti-trash" aria-hidden="true"></i> Sil</button>
          </div>
        </details>
        ` : `
        <button class="baw" style="font-size:12px;padding:9px 12px;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;" onclick="copyRep('${rep.id}')"><i class="ti ti-copy" style="font-size:14px;" aria-hidden="true"></i> Kopyala</button>
        `}
      </div>
      <div class="dmr" style="gap:8px;padding-bottom:4px;flex-wrap:nowrap;overflow-x:auto;">
        <div class="mc"><span class="sp ${sc[rep.status]||'sc'}">${sl[rep.status]||'Taslak'}</span></div>
        ${_medleyN?`<div class="mc"><span class="rep-medley" title="Potpuri: kesintisiz çalınan eser zinciri">🔗 ${_medleyN} Potpuri</span></div>`:''}
        ${rep.date?`<div class="mc" style="white-space:nowrap;">📅 <strong>${rep.date}</strong>${rep.venue?` &nbsp;📍 <strong>${rep.venue}</strong>`:''}</div>`:''}
        ${!rep.date&&rep.venue?`<div class="mc" style="white-space:nowrap;">📍 <strong>${rep.venue}</strong></div>`:''}
        ${rep.isOwner?`<div class="mc"><span class="chip-vis ${rep.is_public?'pub':'priv'}" onclick="togglePublic('${rep.id}')" title="${rep.is_public?'Public — tıkla gizle':'Private — tıkla herkese aç'}">${rep.is_public?'🌐 Public':'🔒 Private'}</span></div>`:''}
        ${rep.notes?`<div class="mc" style="color:var(--text3);white-space:nowrap;display:flex;align-items:center;gap:4px;"><i class="ti ti-pencil-plus" style="font-size:13px;" aria-hidden="true"></i> ${rep.notes}</div>`:''}
      </div>
    </div>
    <div class="is">
      <div class="ih"><h3>${items.length} Eser</h3><button class="baw" onclick="openWM('${rep.id}')">+ Eser Ekle</button></div>
      <table><thead><tr><th class="sq" style="text-align:center;">Sıra</th><th>Eser Adı</th><th class="col-kapanis">Kapanış</th><th class="col-not">Not</th><th></th></tr></thead><tbody>${rows}</tbody></table>
    </div>`;
}

async function togglePublic(repId){
  const rep=getRep(repId);if(!rep)return;
  const newVal=!rep.is_public;
  try{
    await dbPatch('repertoires',repId,{is_public:newVal});
    toast(newVal?'🌐 Repertuvar herkese açık':'🔒 Repertuvar gizlendi');
    await load();
  }catch(e){toast(e.message,'er');}
}

async function copyRep(repId){
  const rep=getRep(repId);if(!rep)return;
  const uid=getUserId();
  sync('spin','Kopyalanıyor...');
  try{
    // Yeni repertuvar oluştur
    const H=authHeaders();
    const r=await fetch(SUPA_URL+'/rest/v1/repertoires',{
      method:'POST',
      headers:{...H,'Prefer':'return=representation'},
      body:JSON.stringify({name:rep.name+' (kopya)',status:'concept',user_id:uid,owner_id:uid,is_public:false})
    });
    if(!r.ok)throw new Error(await r.text());
    const [newRep]=await r.json();
    // Eserleri kopyala
    if(rep.items&&rep.items.length){
      await fetch(SUPA_URL+'/rest/v1/repertoire_items',{
        method:'POST',
        headers:{...H,'Prefer':'return=minimal'},
        body:JSON.stringify(rep.items.map((it,i)=>({repertoire_id:newRep.id,work_id:parseInt(it.workId),seq:i+1,closing_note:it.closingNote||null,note:it.note||null,performer:it.performer||null,linked_prev:i>0&&!!it.linkedPrev})))
      });
    }
    toast('📋 Repertuvar kopyalandı!');
    await load();
    selId=newRep.id;
    renderList();renderDetail();
  }catch(e){sync('err','Hata');toast(e.message,'er');}
}

function openNew(){editId=null;document.getElementById('rmt').textContent='Yeni Repertuvar';['fN','fD','fV','fNo'].forEach(x=>document.getElementById(x).value='');document.getElementById('fS').value='concept';document.getElementById('fVisPublic').checked=true;document.getElementById('rm').style.display='flex';setTimeout(()=>document.getElementById('fN').focus(),50);}
function openEdit(id){const r=getRep(id);if(!r)return;editId=id;document.getElementById('rmt').textContent='Düzenle';document.getElementById('fN').value=r.name;document.getElementById('fD').value=r.date||'';document.getElementById('fV').value=r.venue||'';document.getElementById('fS').value=r.status||'concept';document.getElementById('fNo').value=r.notes||'';if(r.is_public){document.getElementById('fVisPublic').checked=true;}else{document.getElementById('fVisPrivate').checked=true;}document.getElementById('rm').style.display='flex';}
function closeRM(){document.getElementById('rm').style.display='none';}

async function saveRep(){
  const name=document.getElementById('fN').value.trim();
  if(!name){document.getElementById('fN').focus();return;}
  const isPublic=document.getElementById('fVisPublic').checked;
  const data={name,date:document.getElementById('fD').value||null,venue:document.getElementById('fV').value.trim()||null,status:document.getElementById('fS').value,notes:document.getElementById('fNo').value.trim()||null,is_public:isPublic,user_id:getUserId()||undefined,owner_id:editId?undefined:(getUserId()||undefined),group_id:editId?undefined:(getGroupId()||undefined)};
  sync('spin','Kaydediliyor...');
  try{
    if(editId){await dbPatch('repertoires',editId,data);}
    else{const r=await dbPost('repertoires',data);selId=r[0]?.id||r.id;}
    closeRM();toast('Kaydedildi ✓');await load();
  }catch(e){sync('err','Hata');toast(e.message,'er');}
}

async function delRep(id){
  if(!confirm('Bu repertuvarı silmek istiyor musunuz?'))return;
  try{await dbDel('repertoires',id);if(selId===id)selId=null;toast('Silindi');await load();}catch(e){toast(e.message,'er');}
}

function openWM(repId){addRepId=repId;selWId=null;document.getElementById('ws').value='';document.getElementById('fCN').value='';document.getElementById('fIN').value='';document.getElementById('wpl').style.maxHeight='';const dw=document.getElementById('wDupWarn');if(dw)dw.style.display='none';filterW();document.getElementById('wm').style.display='flex';setTimeout(()=>document.getElementById('ws').focus(),50);}

// ── İCRACILAR TAG UI ──
let pfSelected = []; // seçili sanatçılar

function pfRender() {
  const container = document.getElementById('pfTags');
  const input = document.getElementById('pfInput');
  // Remove old tags
  container.querySelectorAll('.pf-tag').forEach(el => el.remove());
  // Insert tags before input
  pfSelected.forEach(name => {
    const tag = document.createElement('span');
    tag.className = 'pf-tag';
    tag.innerHTML = name + '<button type="button" onclick="pfRemove(\''+name+'\')">×</button>';
    container.insertBefore(tag, input);
  });
}

function pfAdd(name) {
  name = name.trim();
  if (!name || pfSelected.includes(name)) return;
  pfSelected.push(name);
  pfRender();
  document.getElementById('pfInput').value = '';
  pfHideDropdown();
}

function pfRemove(name) {
  pfSelected = pfSelected.filter(n => n !== name);
  pfRender();
}

function pfKeydown(e) {
  const val = e.target.value.trim();
  if ((e.key === 'Enter' || e.key === ',') && val) {
    e.preventDefault();
    pfAdd(val);
  } else if (e.key === 'Backspace' && !val && pfSelected.length) {
    pfRemove(pfSelected[pfSelected.length - 1]);
  }
}

function pfSuggest(q) {
  const dd = document.getElementById('pfDropdown');
  if (!q) { pfHideDropdown(); return; }
  const matches = SOLISTLER.filter(n => n.toLowerCase().includes(q.toLowerCase()) && !pfSelected.includes(n));
  if (!matches.length) { pfHideDropdown(); return; }
  dd.innerHTML = matches.slice(0,8).map(n =>
    '<div class="pf-dd-item" onmousedown="event.preventDefault();pfAdd(\''+n+'\')">' + n + '</div>'
  ).join('');
  dd.style.display = 'block';
}

function pfHideDropdown() {
  document.getElementById('pfDropdown').style.display = 'none';
}

function pfReset() {
  pfSelected = [];
  pfRender();
  const inp = document.getElementById('pfInput');
  if (inp) inp.value = '';
  pfHideDropdown();
}

document.addEventListener('click', function(e) {
  if (!e.target.closest('#pfTags') && !e.target.closest('#pfDropdown')) pfHideDropdown();
});
function closeWM(){
  document.getElementById('wm').style.display='none';
  selWId=null; addRepId=null;
  ['fCN','fIN','fMK','ws'].forEach(function(id){var el=document.getElementById(id);if(el)el.value='';});
  pfReset();
  var box=document.getElementById('wInfoBox');if(box)box.style.display='none';
}
function filterW(){
  const q=document.getElementById('ws').value.toLowerCase().trim();
  const list=q?WLIST.filter(w=>(w.name+w.composer+w.makam).toLowerCase().includes(q)):WLIST;
  document.getElementById('wpl').innerHTML=list.slice(0,80).map(w=>`<div class="wpi${selWId===w.id?' sel':''}" onclick="pickW('${w.id}')"><div class="wpn">${w.name}</div><div class="wps">${[w.composer,w.makam].filter(Boolean).join(' · ')}</div></div>`).join('')||'<div style="padding:16px;text-align:center;color:var(--text3);">Bulunamadı</div>';
}
function pickW(id){
  selWId=id;
  const dw=document.getElementById('wDupWarn');if(dw)dw.style.display='none';
  const w=WL[id];
  if(!w) return filterW();
  // Eser adını arama kutusuna yaz
  document.getElementById('ws').value = w.name;
  // Kapanış notasını doldur (boşsa)
  if(w.closingNote && !document.getElementById('fCN').value)
    document.getElementById('fCN').value = w.closingNote;
  // Makamı doldur (readonly)
  document.getElementById('fMK').value = w.makam || '—';
  // Eser bilgi kutusunu göster
  const box = document.getElementById('wInfoBox');
  document.getElementById('wInfoMakam').textContent = w.makam ? '🎵 ' + w.makam : '';
  document.getElementById('wInfoInstr').textContent = w.instrument ? '🎸 ' + w.instrument : '';
  document.getElementById('wInfoComp').textContent = w.composer ? '✍️ ' + w.composer : '';
  box.style.display = (w.makam||w.instrument||w.composer) ? 'block' : 'none';
  // Seçilince listeyi daralt
  document.getElementById("wpl").style.maxHeight = "60px";
  filterW();
}

async function addWork(){
  if(!selWId){alert('Lütfen bir eser seçin.');return;}
  const rep=getRep(addRepId);if(!rep)return;
  const items=rep.items||[];
  if(items.some(i=>String(i.workId)===String(selWId))){
    const dw=document.getElementById('wDupWarn');
    if(dw)dw.style.display='block';
    return;
  }
  const nextSeq=items.length?Math.max(...items.map(i=>i.seq))+1:1;
  sync('spin','Ekleniyor...');
  try{
    await dbPost('repertoire_items',{repertoire_id:addRepId,work_id:selWId,seq:nextSeq,closing_note:document.getElementById('fCN').value.trim()||null,note:document.getElementById('fIN').value.trim()||null,performer:pfSelected.length?pfSelected.join(', '):null});
    closeWM();toast('Eser eklendi ✓');await load();
  }catch(e){toast(e.message,'er');}
}

async function rmItem(repId,itemId,workName){
  if(!confirm((workName||'Bu eser')+' repertuvardan çıkarılsın mı?'))return;
  try{await dbDel('repertoire_items',itemId);toast('Silindi');await load();}catch(e){toast(e.message,'er');}
}


// ── DRAG & DROP (desktop + touch) ──
let _dragSrcIdx = null;
let _dragRepId  = null;
let _touchClone = null;
let _touchSrcTr = null;

// ── Desktop drag ──
function dragStart(e) {
  const tr = e.currentTarget;
  _dragSrcIdx = parseInt(tr.dataset.idx);
  _dragRepId  = tr.dataset.rep;
  e.dataTransfer.effectAllowed = 'move';
  setTimeout(() => tr.style.opacity = '0.4', 0);
}
function dragEnd(e) {
  e.currentTarget.style.opacity = '';
  document.querySelectorAll('tr.drag-over').forEach(r => r.classList.remove('drag-over'));
}
function dragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  document.querySelectorAll('tr.drag-over').forEach(r => r.classList.remove('drag-over'));
  e.currentTarget.classList.add('drag-over');
}
async function dragDrop(e) {
  e.preventDefault();
  const tr = e.currentTarget;
  const destIdx = parseInt(tr.dataset.idx);
  tr.classList.remove('drag-over');
  if (_dragSrcIdx === null || _dragSrcIdx === destIdx) return;
  await mvTo(_dragRepId, _dragSrcIdx, destIdx);
  _dragSrcIdx = null;
}

// ── Touch drag ──
let _touchTimer = null;
function touchDragStart(e) {
  e.stopPropagation();
  const handle = e.currentTarget;
  const tr = handle.closest('tr[data-idx]');
  const t = e.touches[0];
  const startX = t.clientX, startY = t.clientY;

  _touchTimer = setTimeout(() => {
    _dragSrcIdx = parseInt(tr.dataset.idx);
    _dragRepId  = tr.dataset.rep;
    _touchSrcTr = tr;

    _touchClone = tr.cloneNode(true);
    _touchClone.style.cssText = 'position:fixed;z-index:9999;opacity:0.85;pointer-events:none;background:var(--surface2);border:1px solid var(--accent);border-radius:6px;width:'+tr.offsetWidth+'px;transition:none;';
    document.body.appendChild(_touchClone);
    tr.style.opacity = '0.3';
    _touchClone.style.left = (startX - tr.offsetWidth/2) + 'px';
    _touchClone.style.top  = (startY - 20) + 'px';
  }, 300);
}

function touchDragMove(e) {
  if (!_touchClone) return;
  e.preventDefault();
  const t = e.touches[0];
  _touchClone.style.left = (t.clientX - _touchClone.offsetWidth/2) + 'px';
  _touchClone.style.top  = (t.clientY - 20) + 'px';

  // Altındaki satırı bul
  _touchClone.style.display = 'none';
  const el = document.elementFromPoint(t.clientX, t.clientY);
  _touchClone.style.display = '';
  const targetTr = el ? el.closest('tr[data-idx]') : null;
  document.querySelectorAll('tr.drag-over').forEach(r => r.classList.remove('drag-over'));
  if (targetTr) targetTr.classList.add('drag-over');
}

async function touchDragEnd(e) {
  clearTimeout(_touchTimer);
  if (!_touchClone) return;
  _touchClone.remove(); _touchClone = null;
  if (_touchSrcTr) _touchSrcTr.style.opacity = '';
  document.querySelectorAll('tr.drag-over').forEach(r => r.classList.remove('drag-over'));

  const t = e.changedTouches[0];
  const el = document.elementFromPoint(t.clientX, t.clientY);
  const targetTr = el ? el.closest('tr[data-idx]') : null;
  if (!targetTr) { _dragSrcIdx = null; return; }
  const destIdx = parseInt(targetTr.dataset.idx);
  if (_dragSrcIdx === null || _dragSrcIdx === destIdx) { _dragSrcIdx = null; return; }
  await mvTo(_dragRepId, _dragSrcIdx, destIdx);
  _dragSrcIdx = null;
}

function mvActive(repId, idx, dir) {
  // Aktif eser varsa onu taşı, yoksa bu idx'i akifleştir ve taşı
  if (activeItemRepId === repId && activeItemIdx !== null) {
    setActiveItem(repId, activeItemIdx);
    mv(repId, activeItemIdx, dir);
  } else {
    setActiveItem(repId, idx);
    mv(repId, idx, dir);
  }
}

function setActiveItem(repId, idx) {
  activeItemRepId = repId;
  activeItemIdx = idx;
}

// ══ POTPURİ (medley) ══════════════════════════════════════════════════════
// Model: repertoire_items.linked_prev = "bu eser bir öncekiyle KESİNTİSİZ devam eder".
// Potpuri = linked_prev=true olan ARDIŞIK satırların zinciri. Ayrı grup tablosu/id
// yok; böylece sürükle-bırak sıralaması hiçbir tutarlılık kontrolü gerektirmiyor.

// idx'in içinde bulunduğu zincirin [başlangıç, bitiş] aralığı (tek başınaysa [idx,idx])
function chainRange(items, idx){
  let a = idx, b = idx;
  while (a > 0 && items[a].linkedPrev) a--;
  while (b + 1 < items.length && items[b+1].linkedPrev) b++;
  return [a, b];
}
function isChainHead(items, idx){ return !(idx > 0 && items[idx].linkedPrev); }

// ── ZİNCİR NORMALİZASYONU (2026-07-19 b — sürükle-bırak hatası düzeltmesi) ──
// TEK KURAL: bir satırın bağı (linkedPrev) ancak YENİ üstündeki satır, o satırın
// ORİJİNAL zincirinden geliyorsa korunur. Aksi halde bağ otomatik çözülür.
// Bu tek kural şunların hepsini doğru yapar:
//   • zincirden bir parçayı dışarı sürüklemek  → bağ çözülür (altın şerit kalmaz)
//   • zincir İÇİNDE sıra değiştirmek           → bağ korunur
//   • tüm bloğu taşımak                        → bağlar korunur
//   • zincirin ortasına yabancı eser bırakmak  → zincir orada KOPAR (eseri yutmaz)
//   • bir satırın listenin en başına gelmesi   → bağ çözülür (zincir baştan başlayamaz)
function normalizeChains(origItems, merged){
  const chainIdOf = new Map();
  origItems.forEach((it,i)=>{ const [a]=chainRange(origItems,i); chainIdOf.set(String(it.id), String(origItems[a].id)); });
  merged.forEach((it,i)=>{
    if (i === 0) { it.linkedPrev = false; return; }
    if (!it.linkedPrev) return;
    const prev = merged[i-1];
    if (chainIdOf.get(String(prev.id)) !== chainIdOf.get(String(it.id))) it.linkedPrev = false;
  });
}

// Yeni sıralamayı uygula: normalize et, seq'leri yaz, DEĞİŞEN linked_prev'leri yaz.
async function applyReorder(repId, origItems, merged, newActiveIdx){
  const before = new Map(origItems.map(it => [String(it.id), !!it.linkedPrev]));
  normalizeChains(origItems, merged);
  merged.forEach((it,i)=> it.seq = i+1);
  sync('spin','...');
  try{
    const patches = merged.map(it => {
      const body = { seq: it.seq };
      if (before.get(String(it.id)) !== !!it.linkedPrev) body.linked_prev = !!it.linkedPrev;
      return dbPatch('repertoire_items', it.id, body);
    });
    await Promise.all(patches);
    if (activeItemRepId === repId && newActiveIdx != null) activeItemIdx = newActiveIdx;
    await load();
  }catch(e){
    toast(/linked_prev/.test(e.message)?'linked_prev kolonu eksik — SQL\'i çalıştır':e.message,'er');
  }
}

// 🔗 butonu — satırı bir öncekine bağlar / bağı çözer
async function toggleLink(repId, itemId){
  const rep=getRep(repId); if(!rep) return;
  const idx=(rep.items||[]).findIndex(x=>String(x.id)===String(itemId));
  if(idx<=0) return;                       // ilk satır zincir başlatamaz
  const it=rep.items[idx];
  const val=!it.linkedPrev;
  sync('spin','...');
  try{
    await dbPatch('repertoire_items', it.id, {linked_prev: val});
    toast(val?'🔗 Potpuriye bağlandı':'Bağ çözüldü');
    await load();
  }catch(e){
    toast(/linked_prev/.test(e.message)?'linked_prev kolonu eksik — SQL\'i çalıştır':e.message,'er');
  }
}

// ↑/↓ butonları — TEK ADIM. Zincir BAŞINDA basılırsa tüm blok komşu bloğun
// üstüne/altına atlar; zincir içindeki satırda tek satır hareket eder.
async function mv(repId,idx,dir){
  const rep=getRep(repId);if(!rep)return;
  const orig=[...rep.items];
  const [ca,cb]=chainRange(orig,idx);
  const isHead=isChainHead(orig,idx);
  let merged, newActive;
  if(isHead && cb>ca){
    const block=orig.slice(ca,cb+1);
    const rest=[...orig.slice(0,ca),...orig.slice(cb+1)];
    let insertAt;
    if(dir<0){
      if(ca===0) return;
      const [pa]=chainRange(orig,ca-1); insertAt=pa;
    }else{
      if(cb===orig.length-1) return;
      const [,nb]=chainRange(orig,cb+1); insertAt=nb-block.length+1;
    }
    merged=[...rest.slice(0,insertAt),...block,...rest.slice(insertAt)];
    newActive=insertAt;
  }else{
    const ni=idx+dir;
    if(ni<0||ni>=orig.length)return;
    merged=[...orig];
    const [moved]=merged.splice(idx,1);
    merged.splice(ni,0,moved);
    newActive=ni;
  }
  await applyReorder(repId, orig, merged, newActive);
}

// SÜRÜKLE-BIRAK — kaynak satırı hedef sıraya taşır.
// Zincir BAŞI sürüklenirse tüm blok birlikte gider; zincir ÜYESİ sürüklenirse
// yalnız o satır gider ve normalizeChains bağını otomatik çözer.
async function mvTo(repId, srcIdx, destIdx){
  const rep=getRep(repId); if(!rep) return;
  const orig=[...rep.items];
  if(srcIdx==null||destIdx==null||srcIdx<0||srcIdx>=orig.length||destIdx<0||destIdx>=orig.length||srcIdx===destIdx) return;
  const [ca,cb]=chainRange(orig,srcIdx);
  const isHead=isChainHead(orig,srcIdx);
  const moveBlock = isHead && cb>ca;
  const block = moveBlock ? orig.slice(ca,cb+1) : [orig[srcIdx]];
  const from  = moveBlock ? ca : srcIdx;
  const rest  = moveBlock ? [...orig.slice(0,ca),...orig.slice(cb+1)]
                          : [...orig.slice(0,srcIdx),...orig.slice(srcIdx+1)];
  // Hedef satırın kalan listedeki yeri; aşağı taşımada onun ALTINA bırakılır.
  const destItem = orig[destIdx];
  let ins = rest.findIndex(x => String(x.id) === String(destItem.id));
  if (ins < 0) ins = Math.min(from, rest.length);      // hedef, sürüklenen bloğun içindeyse
  else if (destIdx > from) ins = ins + 1;
  const merged=[...rest.slice(0,ins),...block,...rest.slice(ins)];
  await applyReorder(repId, orig, merged, ins);
}

async function chSeq(repId,idx,val){
  const rep=getRep(repId);if(!rep)return;
  const items=[...rep.items];
  const ns=parseInt(val);
  if(isNaN(ns)||ns<1||ns>items.length){renderDetail();return;}
  await mvTo(repId, idx, ns-1);
  return;
}

function printR(repId){
  const rep=getRep(repId);if(!rep)return;
  const items=rep.items||[];
  const sl={concept:'Taslak',confirmed:'Onaylandı',archive:'Arşiv'};
  const rows=items.map(it=>{const w=WL[String(it.workId)]||{};const cn=it.closingNote||w.closingNote||'';return`<tr><td style="width:40px;color:#888;text-align:center;">${it.seq}</td><td style="padding:9px 12px;"><div style="font-weight:500;color:#111;">${w.name||it.workId}</div><div style="font-size:11px;color:#666;">${[w.composer,w.makam].filter(Boolean).join(' · ')}</div></td><td style="width:80px;text-align:center;color:#444;">${cn}</td><td style="width:120px;font-size:12px;color:#666;">${it.note||''}</td></tr>`;}).join('');
  const win=window.open('','_blank','width=800,height=900');
  const printCSS = '*{margin:0;padding:0;box-sizing:border-box;}body{font-family:\'DM Sans\',sans-serif;font-size:14px;color:#111;padding:32px 40px;}h1{font-family:\'Playfair Display\',serif;font-size:28px;font-weight:400;margin-bottom:8px;}hr{border:none;border-top:2px solid #111;margin:16px 0;}table{width:100%;border-collapse:collapse;}th{font-size:10px;font-weight:500;letter-spacing:.1em;text-transform:uppercase;color:#888;text-align:left;padding:6px 12px;border-bottom:1px solid #ddd;}td{padding:9px 12px;border-bottom:1px solid #eee;vertical-align:middle;}';
  const printHTML = '<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><title>' + rep.name + '</title><style>' + printCSS + '</style><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css"></head><body>'
    + '<div style="font-size:11px;color:#999;text-transform:uppercase;letter-spacing:.1em;margin-bottom:24px;">Repertuvar — ' + new Date().toLocaleDateString('tr-TR') + '</div>'
    + '<h1>' + rep.name + '</h1>'
    + '<div style="display:flex;gap:16px;font-size:12px;color:#666;margin-bottom:16px;">' + (rep.date?'\uD83D\uDCC5 '+rep.date:'') + (rep.venue?' \uD83D\uDCCD '+rep.venue:'') + (rep.status?' \u25CF '+sl[rep.status]:'') + ' \uD83C\uDFBC ' + items.length + ' eser</div>'
    + '<hr><table><thead><tr><th>#</th><th>Eser Ad\u0131</th><th>Kapan\u0131\u015f</th><th>Not</th></tr></thead><tbody>' + rows + '</tbody></table>'
    + '<' + 'script>window.onload=function(){setTimeout(function(){window.print();},400);}' + '<\/script>'
    + '</body></html>';
  win.document.write(printHTML);
  win.document.close();
}

document.getElementById('rm').addEventListener('click',e=>{if(e.target.id==='rm')closeRM();});
document.getElementById('wm').addEventListener('click',e=>{if(e.target.id==='wm')closeWM();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeRM();closeWM();}});

// customWorks patch
(function(){
  try {
    var customs = JSON.parse(localStorage.getItem('customWorks') || '[]');
    var deleted = JSON.parse(localStorage.getItem('deletedWorks') || '[]');
    var i, sid;
    for(i=0;i<deleted.length;i++){
      sid = String(parseInt(deleted[i]));
      for(var j=WLIST.length-1;j>=0;j--){ if(WLIST[j].id===sid){WLIST.splice(j,1);break;} }
      delete WL[sid];
    }
    for(i=0;i<customs.length;i++){
      var w = customs[i];
      sid = String(parseInt(w.id));
      var found = false;
      for(var k=0;k<WLIST.length;k++){
        if(WLIST[k].id===sid){
          if(w.name) WLIST[k].name = w.name;
          if(w.composer) WLIST[k].composer = w.composer;
          if(w.makam) WLIST[k].makam = w.makam;
          found = true; break;
        }
      }
      if(!found) WLIST.push({id:sid, name:w.name||'', composer:w.composer||'', makam:w.makam||''});
      if(WL[sid]){
        if(w.name) WL[sid].name = w.name;
        if(w.lyrics !== undefined) WL[sid].lyrics = w.lyrics;
        if(w.composer) WL[sid].composer = w.composer;
      } else {
        WL[sid] = {name:w.name||'',lyrics:w.lyrics||'',composer:w.composer||'',makam:w.makam||'',instrument:w.instrument||'',closingNote:w.closingNote||''};
      }
    }
  } catch(e){ console.warn('patch err',e); }
})();

async function dbPatch(table, id, data) {
  const r = await fetch(SUPA_URL+'/rest/v1/'+table+'?id=eq.'+id, {
    method: 'PATCH',
    headers: {...H, 'Prefer': 'return=minimal'},
    body: JSON.stringify(data)
  });
  if (!r.ok) throw new Error(await r.text());
}
let iemRepId=null,iemItemId=null,iemPfSelected=[];
function openItemEdit(repId,itemId){
  iemRepId=repId;iemItemId=itemId;
  const rep=getRep(repId);if(!rep)return;
  const it=(rep.items||[]).find(x=>x.id===itemId);if(!it)return;
  const w=WL[it.workId]||{};
  const el=function(id){return document.getElementById(id);};
  if(el('iemWorkName')) el('iemWorkName').textContent=w.name||'#'+it.workId;
  if(el('iemWorkInfo')) el('iemWorkInfo').textContent=[w.makam,w.composer].filter(Boolean).join(' · ');
  if(el('iemMK')) el('iemMK').value=w.makam||'—';
  if(el('iemCN')) el('iemCN').value=it.closingNote||w.closingNote||'';
  if(el('iemNote')) el('iemNote').value=it.note||'';
  iemPfSelected=it.performer?it.performer.split(', ').filter(Boolean):[];
  iemPfRender();
  if(el('iem')) el('iem').style.display='flex';
  else console.error('Modal #iem not found in DOM');
}
function closeIEM(){
  document.getElementById('iem').style.display='none';
  iemRepId=null;iemItemId=null;iemPfSelected=[];iemPfRender();
  const inp=document.getElementById('iemPfInput');if(inp)inp.value='';
}
async function saveIEM(){
  try{
    const data={
      closing_note:document.getElementById('iemCN').value.trim()||null,
      note:document.getElementById('iemNote').value.trim()||null,
      performer:iemPfSelected.length?iemPfSelected.join(', '):null
    };
    await dbPatch('repertoire_items',iemItemId,data);
    closeIEM();toast('Kaydedildi ✓');await load();
  }catch(e){toast(e.message,'er');}
}
function iemPfRender(){
  const c=document.getElementById('iemPfTags');if(!c)return;
  const inp=document.getElementById('iemPfInput');
  c.querySelectorAll('.pf-tag').forEach(el=>el.remove());
  iemPfSelected.forEach(name=>{
    const t=document.createElement('span');t.className='pf-tag';
    t.innerHTML=name+'<button type="button" onclick="iemPfRemove(\''+name+'\')">×</button>';
    c.insertBefore(t,inp);
  });
}
function iemPfAdd(name){
  name=name.trim();if(!name||iemPfSelected.includes(name))return;
  iemPfSelected.push(name);iemPfRender();
  document.getElementById('iemPfInput').value='';
  document.getElementById('iemPfDropdown').style.display='none';
}
function iemPfRemove(name){iemPfSelected=iemPfSelected.filter(n=>n!==name);iemPfRender();}
function iemPfKeydown(e){
  const val=e.target.value.trim();
  if((e.key==='Enter'||e.key===',')&&val){e.preventDefault();iemPfAdd(val);}
  else if(e.key==='Backspace'&&!val&&iemPfSelected.length)iemPfRemove(iemPfSelected[iemPfSelected.length-1]);
}
function iemPfSuggest(q){
  const dd=document.getElementById('iemPfDropdown');
  if(!q){dd.style.display='none';return;}
  const m=SOLISTLER.filter(n=>n.toLowerCase().includes(q.toLowerCase())&&!iemPfSelected.includes(n));
  if(!m.length){dd.style.display='none';return;}
  dd.innerHTML=m.slice(0,8).map(n=>'<div class="pf-dd-item" onmousedown="event.preventDefault();iemPfAdd(\''+n+'\')">'+n+'</div>').join('');
  dd.style.display='block';
}
document.addEventListener('click',function(e){
  if(!e.target.closest('#iemPfTags')&&!e.target.closest('#iemPfDropdown')){
    const dd=document.getElementById('iemPfDropdown');if(dd)dd.style.display='none';
  }
});


// ── PAYLAŞIM ──
let shareRepId = null;

function shareRep(repId) {
  shareRepId = repId;
  const rep = getRep(repId);
  if (!rep) return;
  
  // Basit token: rep ID'sini base64'e çevir (yeterince güvenli)
  const token = btoa(repId).replace(/=/g,'');
  const baseUrl = window.location.origin + window.location.pathname.replace('repertoires.html','');
  const link = baseUrl + 'stage.html?share=' + token;
  
  document.getElementById('shareRepName').textContent = rep.name;
  document.getElementById('shareLink').textContent = link;
  document.getElementById('shareLink').dataset.url = link;
  document.getElementById('copyBtn').textContent = 'Kopyala';
  document.getElementById('shareModal').classList.add('open');
}

function closeShare() {
  document.getElementById('shareModal').classList.remove('open');
  shareRepId = null;
}

function copyShareLink() {
  const link = document.getElementById('shareLink').dataset.url;
  navigator.clipboard.writeText(link).then(() => {
    const btn = document.getElementById('copyBtn');
    btn.textContent = '✓ Kopyalandı';
    btn.style.background = '#4ade80';
    setTimeout(() => { btn.textContent = 'Kopyala'; btn.style.background = ''; }, 2000);
  }).catch(() => {
    // Fallback for older browsers
    const el = document.createElement('textarea');
    el.value = link;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    document.getElementById('copyBtn').textContent = '✓ Kopyalandı';
  });
}

function shareViaEmail() {
  const link = document.getElementById('shareLink').dataset.url;
  const rep = getRep(shareRepId);
  const subject = encodeURIComponent('\u1F3B5 ' + (rep ? rep.name : 'Repertuvar') + ' - Sahne Modu');
  const body = encodeURIComponent('Merhaba,\n\n' + (rep ? rep.name : 'Repertuvar') + ' repertuvarini sahne modunda goruntulelemek icin asagidaki baglantıyı kullanabilirsin:\n\n' + link + '\n\nIyi muzikler!');
  window.open('mailto:?subject=' + subject + '&body=' + body, '_blank');
}

function shareViaWhatsApp() {
  const link = document.getElementById('shareLink').dataset.url;
  const rep = getRep(shareRepId);
  const text = '🎵 ' + (rep ? rep.name : 'Repertuvar') + ' — Sahne modunda görüntüle:\n' + link;
  window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
}

(async function() {
  const ok = await requireAuth();
  if(!ok) return;
  // Önce local'den oku ve çiz (load), SONRA sync'i gecikmeyle başlat —
  // böylece açılış okuması, sync'in works yazmasıyla çakışmaz.
  load();
  loadWorksData().then(() => { renderList(); renderDetail(); });
  if (window.syncOfflineData) setTimeout(() => syncOfflineData(), 800);
})();


// --- SYNC/ONLINE OTOMATİK TAZELEME ---
// Ağ değişince (WiFi↔GSM) veya arka plan sync'i bitince veri IndexedDB'de
// güncellenir; ama sayfa açılışta boş kaldıysa kendini çizmiyordu. Bu
// dinleyiciler o durumda listeyi otomatik tazeler. load() local-first
// olduğundan tekrar çağrılması güvenli.
(function() {
  let _refreshT;
  function _refresh() {
    clearTimeout(_refreshT);
    _refreshT = setTimeout(function() {
      if (typeof load === 'function') load();
    }, 150);
  }
  window.addEventListener('data-synced', _refresh);
  window.addEventListener('online', _refresh);
})();
